
package com.assignment.task3;

import java.util.Scanner;

public class Palindrome_3 {
	private static String name;
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a string to check whether palindrome or not");
		name = sc.next();
		int i = 0, j = name.length()-1;
		while(i < j) {
			if(name.charAt(i)!= name.charAt(j)) {
				System.out.println("Not a palindrome");
				System.exit(0);
			}i++;
			j--;
		}System.out.println("Is a palindrome");
		sc.close();
	}
}
