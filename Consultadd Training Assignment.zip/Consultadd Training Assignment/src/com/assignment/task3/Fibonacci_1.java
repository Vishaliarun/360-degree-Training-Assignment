package com.assignment.task3;

import java.util.Scanner;

public class Fibonacci_1 {
	private static int n1 = 0, n2 = 1,n3;

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number to display the fibonacci series");
		int n = sc.nextInt();
		for(int i = 0 ; i <= n;i++) {
			n3 = n1 + n2;
			System.out.println(n3);
			n1 = n2;
			n2 = n3;
	}sc.close();
	}
}
