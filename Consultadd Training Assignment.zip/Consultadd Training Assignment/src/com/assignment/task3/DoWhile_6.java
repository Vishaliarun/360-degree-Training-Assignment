package com.assignment.task3;

import java.util.Scanner;

public class DoWhile_6 {
	private static int a;
	private static int b;
	private static String s;

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		do {
			System.out.println("Enter the value of a and b");
			a = sc.nextInt();
			b = sc.nextInt();
			int c = a + b;
			System.out.println(c);
			System.out.println("Do you want to perform the operation again");
			s = sc.next();
		}while(s!=null);
		sc.close();
	}
}
