package com.assignment.task3;

import java.util.Scanner;

public class SumOfEven_5 {
	private static int n, sum = 0;
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a digit to find the sum of even numbers");
		n = sc.nextInt();
		int i = 0;
		while(i <= n) {
			if(i % 2 == 0) {
				sum = sum + i;
			}i++;
	}System.out.println(sum);
	sc.close();

}}


