package com.assignment.task3;

import java.util.Scanner;

public class LargestAndSmallest_8 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the length of the array to store the elements");
		int len = sc.nextInt();
		int arr[] = new int[len];
		System.out.println("Enter the numbers");
		for(int i = 0;i < arr.length;i++) {
			arr[i] = sc.nextInt();
//			System.out.println(arr[i]);
		}
		int max =arr[0];
		int min =arr[0];
		for(int j = 0;j < arr.length;j++) {
			if(arr[j] > max) {
				max = arr[j];
			}else if(arr[j] < min){
				min = arr[j];
			}	
		}System.out.println("The largest is "+max+" and the smallest is "+min);
		sc.close();
	}
	

}
