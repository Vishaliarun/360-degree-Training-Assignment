package com.assignment.task4;

public class Arrays_6 {
	private static int arr[] = { 1, 2, 4, 5, 6 };
	private static int sum[] = new int[5];
	
	public static void main(String[] args) {
		for(int i = 0;i < arr.length;i++) {
			sum[i] = arr[1] + arr[2];
			System.out.print(sum[i]+" ");
			return;
		}
	}
}
