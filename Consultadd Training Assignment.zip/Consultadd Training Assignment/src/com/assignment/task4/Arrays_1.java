package com.assignment.task4;

import java.util.Scanner;

public class Arrays_1 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the length of the array");
		int length = sc.nextInt();
		int myArray[] = new int[length];
		
		System.out.println("Enter the elements");
		for(int i = 0;i < length;i++) {
			myArray[i] = sc.nextInt();
		}
		for(int i = 0;i < length;i++) {
			System.out.println(myArray[i]);
		}sc.close();
	}

}
