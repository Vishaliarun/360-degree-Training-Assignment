package com.assignment.task4;


public class Array_8 {
	private static int arr[] = {1,16,2,19,10,20};
	public static void main(String[] args) {
		int max1 = arr[0];
		int max2 = 0 ;
		int max3 = 0 ;
		
		for(int i = 0;i <= 3;i++) {
			if(arr[i] > max1) {
				max1 =arr[i];
			}
			if(arr[i] > max1) {
				max2 = max1;
				max1 = arr[i];
			}
			if(arr[i] >max2) {
				max3 = max2;
				max2 = max1;
				max1= arr[i];
			}
		}System.out.println(max3);
		
	}
	}
