package com.assignment.task4;

import java.util.Scanner;

public class Arrays_4 {
	static int myNum[] = {1,2,3,4,5,6,7,8,9,10};
	
	
	public static void main(String[] args) {
		boolean flag = false;
		
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter a number from 0 to 10");
		int num = sc.nextInt();
		
		int end = myNum.length -1;
		int start = 0;
		
		while(start <= end) {
			int mid = (start+end)/2;
			
			if(myNum[mid] == num) {
				System.out.println("Element found");
				flag = true;
				break;
			}
			if(myNum[mid] < num) {
				start = mid + 1;
			}
			if(myNum[mid] > num) {
				end = mid - 1;
			}
		}
		if(flag == false) {
			System.out.println("Element Not found");
		}sc.close();
	}
}
