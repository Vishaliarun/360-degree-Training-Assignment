package com.assignment.task4;

import java.util.Scanner;

public class Arrays_3 {
	
	public static void main(String[] args) {
		final int myNum[] = {2,4,9,1,6};
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter a number from 0 to 10");
		int num = sc.nextInt();
		check(myNum,num);
		sc.close();
	}

	private static void check(int[] myNum, int num) {
		for(int i = 0;i <myNum.length;i++) {
			if(myNum[i] == num) {
				System.out.println("is present");
				return;
			}
//				else {
//				System.out.println("not present");
//			}
		}System.out.println("not present");
		
	}

	}
