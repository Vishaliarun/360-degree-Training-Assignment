package com.assignment.task4;

public class Arrays_2 {
	private static int number[] = {2,8,4,1,3};
	private static int sum = 0;
	private static double average;
	public static void main(String[] args) {
		for(int i = 0;i < number.length;i++) {
			sum = sum + number[i];
			average = (double)sum /number.length;
		}System.out.println(average);
	}

}
