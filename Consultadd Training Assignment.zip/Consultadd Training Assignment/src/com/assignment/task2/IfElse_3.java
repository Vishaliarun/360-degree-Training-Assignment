package com.assignment.task2;

import java.util.Scanner;

public class IfElse_3 {
	private static int dividend;
	private static int divisor;
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the value of dividend and divisor ");
		dividend = sc.nextInt();
		divisor = sc.nextInt();
		int quotient = dividend / divisor;
		int remainder = dividend % divisor;
		System.out.println("quotient is "+quotient);
		System.out.println("remainder is "+remainder);
		sc.close();
		

	}

}
