package com.assignment.task2;

public class IfElse_2 {
	private static char ch = 'A';
	private static char ch1 = 12;

	public static void main(String[] args) {
		if ((ch >= 65 && ch <= 90) || (ch >= 97 && ch <= 122)) {
			System.out.println("Character is an alphabet");
		} else {
			System.out.println("Character is not an alphabet");
		}
		if ((ch1 >= 65 && ch1 <= 90) || (ch1 >= 97 && ch1 <= 122)) {
			System.out.println("Character is an alphabet");
		} else {
			System.out.println("Character is not an alphabet");
		}
	}

}
