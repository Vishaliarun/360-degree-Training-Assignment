package com.assignment.task2;

import java.util.Scanner;

public class IfElse_6 {
	private static int a;
	private static int b;
	private static String c;
	private static int d;

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the value of a and b ");
		a = sc.nextInt();
		b = sc.nextInt();
		System.out.println("Enter the operation to be performed");
		c = sc.next();
		switch (c) {
		case "+":
			d = a + b;
			System.out.println("Sum of the numbers are " + d);
			break;
		case "-":
			d = a - b;
			System.out.println("Difference of the numbers are " + d);
			break;
		case "*":
			d = a * b;
			System.out.println("Product of the numbers are " + d);
			break;
		case "/":
			d = a / b;
			System.out.println("Quotient is " + d);
			break;
		case "%":
			d = a % b;
			System.out.println("Remainder is " + d);
			break;
		default:
			System.out.println("Invalid operation");
			break;
		}
		sc.close();
	}

}
