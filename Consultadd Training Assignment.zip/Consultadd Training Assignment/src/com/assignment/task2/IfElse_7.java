package com.assignment.task2;

import java.util.Scanner;

public class IfElse_7 {
	private static int a;

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
	}}
