package com.assignment.task2;

import java.util.Scanner;

public class IfElse_4 {
	public int year;

	public IfElse_4() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a year");
		year = sc.nextInt();
		sc.close();
	}

	public void check() {
		if ((year % 4 == 0) && (year % 100 != 0)) {
			System.out.println("It is a leap year");
		} else if (year % 400 == 0) {
			System.out.println("It is a leap year");
		} else
			System.out.println("It is not a leap year");
	}

	public static void main(String[] args) {
		IfElse_4 obj1 = new IfElse_4();
		obj1.check();
	}

}
