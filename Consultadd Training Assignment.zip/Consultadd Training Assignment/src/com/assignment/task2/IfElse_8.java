package com.assignment.task2;

import java.util.Scanner;

public class IfElse_8 {
	private static double income_Amount;
	private static double tax_Amount;

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the income amount");
		income_Amount = sc.nextDouble();
		if ((income_Amount >= 250000) && (income_Amount < 600000)) {
			tax_Amount = 10 *income_Amount/100;
			System.out.println("Tax Amount is "+tax_Amount);
		}else if((income_Amount >= 600000) && (income_Amount < 1200000)) {
			tax_Amount = 18 *income_Amount/100;
			System.out.println("Tax Amount is "+tax_Amount);
		}else if(income_Amount > 1200000) {
			tax_Amount = 25 *income_Amount/100;
			System.out.println("Tax Amount is "+tax_Amount);
		}else {
			System.out.println("Invalid amount,please enter an amount greater than 250000");
		}
}}
