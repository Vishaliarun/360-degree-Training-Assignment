package com.assignment.task2;

import java.util.Scanner;

public class IfElse_1 {
	private static int a;

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the value of a ");
		a = sc.nextInt();
		if (a > 0) {
			System.out.println("number is positive");
		} else {
			System.out.println("number is negative");
		}
		sc.close();
	}

}
