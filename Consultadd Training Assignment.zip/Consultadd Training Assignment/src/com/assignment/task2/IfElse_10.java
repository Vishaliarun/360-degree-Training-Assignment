package com.assignment.task2;

import java.util.Scanner;

public class IfElse_10 {
	private static int basic_Salary;
	private static double gross_Salary;
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your basic salary");
		basic_Salary = sc.nextInt();
		if(basic_Salary <= 15000) {
			gross_Salary = 25 * basic_Salary/100 + 82 * basic_Salary/100;
			System.out.println("Your gross salary is "+gross_Salary);
		}else if(basic_Salary <= 20200) {
			gross_Salary = 27 * basic_Salary/100 + 90 * basic_Salary/100;
			System.out.println("Your gross salary is "+gross_Salary);
		}else if(basic_Salary > 20200) {
			gross_Salary = 36 * basic_Salary/100 + 95 * basic_Salary/100;
			System.out.println("Your gross salary is "+gross_Salary);
		}else {
			System.out.println("Invalid basic salary");
		}sc.close();
	}
}
