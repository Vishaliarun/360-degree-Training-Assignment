package com.assignment.task6;

public class MainTriangle {
	public static void main(String[] args) {
		Triangle tri = new Triangle();
		tri.area();
		tri.perimeter();
	}

}
