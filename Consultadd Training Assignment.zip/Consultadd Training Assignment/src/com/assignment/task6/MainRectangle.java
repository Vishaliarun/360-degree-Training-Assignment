package com.assignment.task6;

public class MainRectangle {
	public static void main(String[] args) {
		Rectangle rect = new Rectangle();
		System.out.println(rect);
		Rectangle rect1 = new Rectangle(10,20);
		System.out.println(rect1);
		Rectangle rect2 = new Rectangle(30);
		System.out.println(rect2);
		
	}
}
