package com.assignment.task6;

public class Employee {
	private String name;
	private int yearOfJoining;
	private String address;
	
	public Employee(String name, int yearOfJoining, String address) {
		super();
		this.name = name;
		this.yearOfJoining = yearOfJoining;
		this.address = address;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getYearOfJoining() {
		return yearOfJoining;
	}
	public void setYearOfJoining(int yearOfJoining) {
		this.yearOfJoining = yearOfJoining;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Employee [name=" + name + ", yearOfJoining=" + yearOfJoining + ", address=" + address + "]";
	}
	
	

}
