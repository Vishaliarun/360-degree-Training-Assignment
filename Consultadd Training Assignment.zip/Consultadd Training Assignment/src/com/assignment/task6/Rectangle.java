package com.assignment.task6;

public class Rectangle {
	private int length;
	private int breadth;
	private int lb;
	
	public void area() {
		int area = length * breadth;
		System.out.println(area);
	}
	public Rectangle() {
		length = 0;
		breadth =0;
		area();
	}
	public Rectangle(int length, int breadth) {
		this.length = length;
		this.breadth = breadth;
		area();
	}
	public Rectangle(int lb) {
		this.lb = lb;
		length = breadth = lb;
		area();
	}
	@Override
	public String toString() {
		return "Rectangle [length=" + length + ", breadth=" + breadth + ", lb=" + lb + "]";
	}
}
