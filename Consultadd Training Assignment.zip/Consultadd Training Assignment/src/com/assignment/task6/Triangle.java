package com.assignment.task6;

public class Triangle {
	public int length = 3;
	public int base = 4;
	public int height = 5;

	public void area() {
		int area = (int) (0.5 * base * height);
		System.out.println("Area is " + area);
	}

	public void perimeter() {
		int perimeter = length + base + height;
		System.out.println("Perimeter is " + perimeter);
	}


}
