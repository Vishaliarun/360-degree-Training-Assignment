package com.assignment.task6;

public class Student {
	public String name = "Amay";
	public int enrollmentNo = 132;
	public static void main(String[] args) {
		Student std = new Student();
		System.out.println(std.name+" "+std.enrollmentNo);
	}
}
