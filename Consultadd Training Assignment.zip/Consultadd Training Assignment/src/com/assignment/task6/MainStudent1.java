package com.assignment.task6;

public class MainStudent1 {
	public static void main(String[] args) {
		Student1 std = new Student1();
		System.out.println(std.studentName());
		Student1 std1 = new Student1();
		System.out.println(std1.studentName("visha"));
	}
	
	

}
