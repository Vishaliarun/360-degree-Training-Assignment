package com.assignment.task6;

public class Student1 {
	public String studentName() {
		return "Unknown";
	}
	public String studentName(String name) {
		return name;
	}
}
