package com.assignment.task6;

public class MainEmployee {
	public static void main(String[] args) {
		Employee e1 = new Employee("Robert",1994,"64C-Walls Street");
		Employee e2 = new Employee("Sam",2000,"68D-Walls Street");
		Employee e3 = new Employee("John",1999,"26B-Walls Street");
		System.out.println(e1);
		System.out.println(e2);
		System.out.println(e3);
		
	}

}
