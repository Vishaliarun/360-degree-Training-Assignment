package com.assignment.task5;

import java.util.StringTokenizer;

public class Strings_7 {

	public static String name = "Be Happy and Stay Motivated";
	public static String revName = " ";
	public static void main(String[] args) {
		StringTokenizer st = new StringTokenizer(name);
		while(st.hasMoreTokens()) {
			revName = st.nextToken();
			StringBuilder sb = new StringBuilder(revName);
			sb.reverse();
			System.out.print(sb+" ");
		}
	}
}

