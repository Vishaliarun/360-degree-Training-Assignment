package com.assignment.task5;

public class Strings_5 {
	private static String name = "visha";
	private static int vowels = 0;
	private static int consonants = 0;

	public static void main(String[] args) {
		for (int i = 0; i < name.length(); i++) {
			char ch = name.charAt(i);
			if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
				++vowels;
			} else if ((ch >= 'a' && ch <= 'z')) {
				++consonants;
			}
		}System.out.println("Total number of vowels are "+vowels+" "+"and consonants are "+consonants);
		
	}

}
