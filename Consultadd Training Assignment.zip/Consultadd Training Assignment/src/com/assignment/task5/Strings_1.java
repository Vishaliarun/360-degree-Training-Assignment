package com.assignment.task5;

public class Strings_1 {
	public static String name = "Consultadd";
	public static char ch;
	public static String revName = " ";
	public static void main(String[] args) {
//		StringBuilder sb = new StringBuilder(name);
//		sb.reverse();
//		System.out.println(sb);
//	}
		for(int i= 0;i<name.length();i++) {
			ch = name.charAt(i);
			revName = ch+revName;
		}System.out.println(revName);
	}
}
