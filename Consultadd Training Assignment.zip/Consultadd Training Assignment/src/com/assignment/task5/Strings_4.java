package com.assignment.task5;

import java.io.IOException;
import java.util.Scanner;

public class Strings_4 {
	private static String name;
	private static char ch;
	private static int count = 0;
	public static void main(String[] args) throws IOException {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a string");
		name = sc.next();
		System.out.println("Enter a character to find its occurence");
		ch = (char) System.in.read();
		for(int i =0;i<name.length();i++) {
			if(name.charAt(i)== ch) {
				count++;
			}
		}System.out.println(count);
		sc.close();
	}

}
