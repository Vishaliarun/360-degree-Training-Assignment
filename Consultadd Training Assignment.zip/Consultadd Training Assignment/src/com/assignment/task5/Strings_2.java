package com.assignment.task5;

import java.util.StringTokenizer;

public class Strings_2 {
	public static String name = "Consultadd Pvt";
	public static String revName = " ";
	public static void main(String[] args) {
		StringTokenizer st = new StringTokenizer(name);
		while(st.hasMoreTokens()) {
			revName = st.nextToken();
			StringBuilder sb = new StringBuilder(revName);
			sb.reverse();
			System.out.print(sb+" ");
		}
	}
}
