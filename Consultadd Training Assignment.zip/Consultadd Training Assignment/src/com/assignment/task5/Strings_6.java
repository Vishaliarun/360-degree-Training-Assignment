package com.assignment.task5;

public class Strings_6 {
	private static String str = "Have a nice day";
	private static String str1 = "day";

	public static void main(String[] args) {
		boolean test = str.contains(str1);
		if (test) {
			System.out.println("str1 is present in str");
		} else {
			System.out.println("str1 is not present in str");
		}
	}
}
