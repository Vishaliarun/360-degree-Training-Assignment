package com.assignment.task1;

public class Basics_1 {
	private static String myName = "vishali";

	public static void main(String[] args) {
		System.out.println(myName);

	}

}
