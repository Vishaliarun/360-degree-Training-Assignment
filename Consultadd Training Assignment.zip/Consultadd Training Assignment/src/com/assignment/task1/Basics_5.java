package com.assignment.task1;

import java.util.Scanner;

public class Basics_5 {
	private static int radius;

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the radius ");
		radius = sc.nextInt();
		double area = 3.14 * radius * radius;
		System.out.println("Area of Circle is " + area);
		sc.close();

	}

}
