package com.assignment.task1;

public class Basics_3 {
	static int a = 10;
	static int b = 20;
	static int temp;

	public static void main(String[] args) {
		System.out.println("Swapping using 3rd variable");
		System.out.println();
		System.out.println("Value of a and b before swapping " + a + " " + b);
		temp = a;
		a = b;
		b = temp;
		System.out.println("Value of a and b after swapping " + a + " " + b);
		System.out.println();
		System.out.println("Swapping without using 3rd variable");
		System.out.println();
		System.out.println("Value of a and b before swapping " + a + " " + b);
		a = a + b;
		b = a - b;
		a = a - b;
		System.out.println("Value of a and b after swapping " + a + " " + b);

	}

}
