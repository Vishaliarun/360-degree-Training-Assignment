package com.assignment.task1;

import java.util.Scanner;

public class Basics_2 {
	static String name;

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your name ");
		name = sc.next();
		System.out.println(name);
		sc.close();

	}

}
