package com.assignment.task1;

import java.util.Scanner;

public class Basics_4 {
	private static float a;
	private static int b;
	private static float c;

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the value of a and b ");
		a = sc.nextFloat();
		b = sc.nextInt();
		c = a + b;
		System.out.println("Sum of two numbers are " + c);
		sc.close();

	}

}
