package com.assignment.task7;

import java.util.HashMap;
import java.util.Map;

public class Programming_10 {
	public static void main(String[] args) {
		HashMap<Integer,String> map = new HashMap<>();
		map.put(1, "visha");
		map.put(4, "nisha");
		map.put(3, "usha");
		map.put(2, "asha");
		
		for(Map.Entry<Integer, String> i :map.entrySet()) {
			System.out.println(i.getKey()+" "+i.getValue());
		}
		
	}

}
