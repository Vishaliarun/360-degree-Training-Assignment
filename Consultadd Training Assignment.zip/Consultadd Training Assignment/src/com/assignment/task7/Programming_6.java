package com.assignment.task7;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Programming_6 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the string");
		String s = sc.nextLine();
		
		ArrayList<Character> list = new ArrayList<>();
		for(int i = 0;i<s.length();i++) {
			list.add(s.charAt(i));
			}
		HashMap<Character, Integer> map = new HashMap<>();
		for(int i = 0;i < s.length();i++) {
			map.putIfAbsent(list.get(i), Collections.frequency(list, list.get(i)));
		}
		for(Map.Entry<Character, Integer> map1:map.entrySet()) {
			System.out.println("Character "+map1.getKey()+" has occurred "+map1.getValue()+" times");
		}
		sc.close();
	}

}
