package com.assignment.task7;

import java.util.Scanner;

public class Programming_4 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the String");
		String s= sc.nextLine();
		int count = 1;
		for(int i = 0;i < s.length()-1;i++) {
			if((s.charAt(i)== ' ') && (s.charAt(i+1)!= ' ')) {
				count++;
			}
		}System.out.println("No of words in the given string is "+count);
		sc.close();
}
}
