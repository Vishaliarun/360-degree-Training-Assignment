package com.assignment.task7;

import java.util.Scanner;

public class Programming_5 {
	public static void main(String[] args) {
		int n, temp,armstrong = 0;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number to check if it is armstrong");
		n = sc.nextInt();
		int original = n;
		while(n > 0) {
			temp = n % 10;
			temp = (int) Math.pow(temp, 3);
			armstrong = armstrong + temp;
			n= n /10;
		}
			if(armstrong == original) {
				System.out.println("It is a armstrong number");
			}else {
				System.out.println("It is NOt a armstrong number");
			}
			sc.close();
	}

}
