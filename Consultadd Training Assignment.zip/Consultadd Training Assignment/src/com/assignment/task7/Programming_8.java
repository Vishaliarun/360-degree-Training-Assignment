package com.assignment.task7;

public class Programming_8 {
	  public static void main(String[] args) {
	      String[] str = {"hi", "good morning", "have","a","nice","day"};
	      int max = 0;
	      String longestString = null;
	      for (String s : str) {
	          if (s.length() > max) {
	              max = s.length();
	              longestString = s;
	          }
	      }
	      System.out.println("Length of the longest string is "+max);
	      System.out.println("The String is "+longestString);
	  }
}